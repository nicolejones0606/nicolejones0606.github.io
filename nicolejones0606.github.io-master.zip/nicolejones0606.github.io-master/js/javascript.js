/***
This is just an example that shows how to pull different kinds of form data. You can use this as reference for later projects.

***/


// Setup variables:
var donate;
var netWorth;
var twitter;

// Create the function to process the form. This function will run when the form is submitted. You need to create this function before attaching it to the event, below

var processForm = function(event) {

	// This function receives one parameter -- the event that called it. We'll use this parameter at the very end of the function to prevent the form from actually submitting.

	// Radio Buttons
	var radioButtons = document.getElementsByName('donate');
	for (var i = 0; i < radioButtons.length; i++) {
			if (radioButtons[i].checked) {
				donate = radioButtons[i].value;
				break; // quits the for loop once you find the option that's selected
			}
	}
	console.log("Do they donate: " + donate);


	// Select for Net Worth
	var netWorthElement = document.getElementById('netWorth');
	var netWorthValue = netWorthElement.options[netWorthElement.selectedIndex].value;
	console.log("Net Worth: " + netWorthValue);

  // Select for Twitter
  var twitterElement = document.getElementById('twitter');
  var twitterValue = twitterElement.options[twitterElement.selectedIndex].value;
  console.log("Twitter: " + twitterValue);


	event.preventDefault(); // Stop the form from submitting.

} // end processForm

// Find the form:
var form = document.getElementById('profileForm');

// Attach a function to the form's submit event:
form.addEventListener('submit', processForm, false);


// If the user selects specific parameters, then certain code will display:

var celebrityOutput =
